package entidade;

public class aluno {

    public String nome;
    public double nota1;
    public double nota2;
    public double nota3;

    public double somaNotas(){
return nota1 + nota2 + nota3;
    }

    public String resultadoFinal(){
        if (somaNotas() > 60.0) {
            return "APROVADO";
        } else {
            return "REPROVADO, Faltam" + (somaNotas() - 60.0) + "pontos.";
        }
    }

}


